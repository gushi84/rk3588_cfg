#ifndef VTPM_COMMON_TYPES
#define VTPM_COMMON_TYPES 1
typedef unsigned char BYTE;
typedef unsigned char BOOL;
typedef unsigned char UINT8;
typedef uint16_t UINT16;
typedef uint32_t UINT32;
typedef uint64_t UINT64;
#endif
