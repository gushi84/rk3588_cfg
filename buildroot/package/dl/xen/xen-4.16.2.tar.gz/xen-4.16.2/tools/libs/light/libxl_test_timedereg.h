#ifndef TEST_TIMEDEREG_H
#define TEST_TIMEDEREG_H

#include <pthread.h>

int libxl_test_timedereg(libxl_ctx *ctx, libxl_asyncop_how *ao_how)
    LIBXL_EXTERNAL_CALLERS_ONLY;

#endif /*TEST_TIMEDEREG_H*/
